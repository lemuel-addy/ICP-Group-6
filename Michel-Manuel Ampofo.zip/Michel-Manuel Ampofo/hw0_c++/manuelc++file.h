include <iostream>
using namespace std;
int main(){
	cout<< "Hello, I am all set up for C++ for ICP\n";
	return 0 
}
