#include <iostream>

using namespace std;


#include<iostream>
#include<fstream>
#include<cctype>
#include<iomanip>
using namespace std;
typedef std::string String;

//***************************************************************
//                   CLASS USED IN PROJECT
//****************************************************************



typedef struct{
    String userEmail;
    String name;
    String dateofBirth;
    double gpa;
    int yearGroup;
    bool auth;
    bool isAdmin;
    bool isFaculty;
} users;

class account
{
public:
    users everyUsers[100];
    int userNo=0;

    String create_account(String, String, String, double, int, bool);
    //void create_account();  //function to get data from user
    void viewProfile() ;
    String updateProfile();
    String isAdmin(String);
    String makeFaculty(String);
    String isFaculty(String);
    String login(String);
};

//Function used to create a user account
String account::create_account(String userEmail,
    String name,
    String dateofBirth,
    double gpa,
    int yearGroup,
    bool isAdmin
    ) {
        everyUsers[userNo].userEmail=userEmail;
        everyUsers[userNo].name=name;
        everyUsers[userNo].dateofBirth=dateofBirth;
        everyUsers[userNo].yearGroup=yearGroup;
        everyUsers[userNo].isAdmin=isAdmin;
        userNo+=1;

        return "done";
}

String account::login(String email){
    for(users &user: this->everyUsers){
        if (user.userEmail==email){
            user.auth=true;
            return "user logged";
        }
    }
    return "problem";
}

String account::makeFaculty(String email){
    for(users &user: this->everyUsers){
        if (user.userEmail==email){
            user.isFaculty=true;
            return "user now faculty";
        }
    }
    return "problem";
}
String account::isAdmin(String email){
    for(users &user: this->everyUsers){
        if (user.userEmail==email){
                if (user.isAdmin){return "user is admin";}
                else{return "user not admin";}
        }
    }
    return "problem";
}
String account::isFaculty(String email){
    for(users &user: this->everyUsers){
        if (user.userEmail==email){
                if (user.isFaculty){return "user is faculty";}
                else{return "user not faculty";}
        }
    }
    return "problem";
}


int main()
{
    account ac;
    String n= ac.create_account( "userEmail", "name", "dateofBirth", 4.0,2020, true);
    String l= ac.login("userEmail");
     std::cout << n << std::endl;
     std::cout << l << std::endl;
     std::cout<< std:: boolalpha<< ac.everyUsers[0].auth<< endl;
     std::cout << ac.isAdmin("userEmail") << std::endl;
     std::cout << ac.isFaculty("userEmail") << std::endl;
     std::cout << ac.makeFaculty("userEmail") << std::endl;
     std::cout << ac.isFaculty("userEmail") << std::endl;

}
